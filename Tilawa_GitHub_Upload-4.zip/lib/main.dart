import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

void main() => runApp(const TilawaApp());

const navy = Color(0xFF102A43);
const blue = Color(0xFF1976D2);
const pale = Color(0xFFEAF4FF);

class TilawaApp extends StatelessWidget {
  const TilawaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'تلاوة',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: blue), scaffoldBackgroundColor: const Color(0xFFF7FAFE)),
    home: const MainScreen(),
  );
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override
  State<MainScreen> createState() => _MainScreenState();
}
class _MainScreenState extends State<MainScreen> {
  int page = 0;
  bool mic = false;
  TimeOfDay reminder = const TimeOfDay(hour: 6, minute: 0);
  Future<void> askMic() async {
    final result = await Permission.microphone.request();
    setState(() => mic = result.isGranted);
    if (!result.isGranted && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لم يتم السماح باستخدام الميكروفون')));
    }
  }
  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onOpen: (i) => setState(() => page = i)),
      const QuranPage(),
      MicPage(granted: mic, onAsk: askMic),
      const PrayerPage(),
      SettingsPage(reminder: reminder, onTime: (t) => setState(() => reminder = t)),
    ];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Text('📖 تلاوة', style: TextStyle(fontWeight: FontWeight.w800, color: navy)), backgroundColor: Colors.white),
      body: SafeArea(child: pages[page]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: page, onDestinationSelected: (i) => setState(() => page = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'المصحف'),
          NavigationDestination(icon: Icon(Icons.mic_none), label: 'التسميع'),
          NavigationDestination(icon: Icon(Icons.mosque_outlined), label: 'الصلاة'),
          NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'الإعدادات'),
        ],
      ),
    ));
  }
}

class HomePage extends StatelessWidget {
  final ValueChanged<int> onOpen;
  const HomePage({super.key, required this.onOpen});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Container(padding: const EdgeInsets.all(23), decoration: BoxDecoration(gradient: const LinearGradient(colors: [navy, blue]), borderRadius: BorderRadius.circular(24)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text('السلام عليكم ورحمة الله', style: TextStyle(color: Colors.white70)),
      SizedBox(height: 10), Text('اجعل لك وردًا من القرآن', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
      SizedBox(height: 8), Text('اقرأ • احفظ • راجع • ارتقِ', style: TextStyle(color: Colors.white70)),
    ])),
    const SizedBox(height: 20), const Text('ابدأ رحلتك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
    const SizedBox(height: 12),
    GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.25, children: [
      _tile(Icons.menu_book, 'المصحف الشريف', 'قراءة القرآن', () => onOpen(1)),
      _tile(Icons.mic, 'التسميع', 'إذن الميكروفون', () => onOpen(2)),
      _tile(Icons.mosque, 'الصلاة والأذان', 'مواقيت الصلاة', () => onOpen(3)),
      _tile(Icons.alarm, 'منبّه الورد', 'تذكير يومي', () => onOpen(4)),
    ]),
    const SizedBox(height: 16), const Card(color: pale, child: Padding(padding: EdgeInsets.all(18), child: Text('القليل الدائم خير من الكثير المنقطع.', style: TextStyle(color: navy, fontWeight: FontWeight.w600)))),
  ]);
  Widget _tile(IconData icon, String title, String sub, VoidCallback tap) => InkWell(onTap: tap, borderRadius: BorderRadius.circular(18), child: Ink(decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFE3ECF6))), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, color: blue, size: 28), const SizedBox(height: 8), Text(title, style: const TextStyle(color: navy, fontWeight: FontWeight.bold)), Text(sub, style: const TextStyle(color: Colors.black54, fontSize: 12))]))));
}

class QuranPage extends StatelessWidget {
  const QuranPage({super.key});
  @override
  Widget build(BuildContext context) => const Padding(padding: EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text('المصحف الشريف', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: navy)),
    SizedBox(height: 12), Text('سيُضاف نص المصحف الكامل بعد إدراج مصدر موثوق ومراجع. لا يحتوي هذا الإصدار التجريبي على نص الآيات بعد.', style: TextStyle(height: 1.8, color: Colors.black54)),
  ]));
}
class MicPage extends StatelessWidget {
  final bool granted; final VoidCallback onAsk;
  const MicPage({super.key, required this.granted, required this.onAsk});
  @override
  Widget build(BuildContext context) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
    const Icon(Icons.mic, color: blue, size: 65), const SizedBox(height: 18),
    const Text('التسميع والمراجعة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: navy)),
    const SizedBox(height: 10), const Text('اطلب إذن الميكروفون عند رغبتك. التسجيل وتحليل التلاوة غير مفعّلين في هذا الإصدار.', textAlign: TextAlign.center, style: TextStyle(height: 1.7, color: Colors.black54)),
    const SizedBox(height: 18), FilledButton.icon(onPressed: onAsk, icon: const Icon(Icons.mic), label: Text(granted ? 'تم السماح بالميكروفون' : 'السماح بالميكروفون')),
  ])));
}
class PrayerPage extends StatelessWidget {
  const PrayerPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: const [
    Text('الصلاة والأذان', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: navy)),
    SizedBox(height: 12), Card(child: Padding(padding: EdgeInsets.all(18), child: Text('سيتم إضافة مواقيت الصلاة بعد تحديد المدينة وطريقة الحساب ومصدر موثوق. الأذان التلقائي غير مفعّل في هذه النسخة.', style: TextStyle(height: 1.8)))),
  ]);
}
class SettingsPage extends StatelessWidget {
  final TimeOfDay reminder; final ValueChanged<TimeOfDay> onTime;
  const SettingsPage({super.key, required this.reminder, required this.onTime});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('الإعدادات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: navy)),
    Card(child: ListTile(leading: const Icon(Icons.alarm, color: blue), title: const Text('وقت منبّه الورد'), subtitle: Text(reminder.format(context)), onTap: () async { final t = await showTimePicker(context: context, initialTime: reminder); if (t != null) onTime(t); })),
    const SizedBox(height: 16), const Card(color: pale, child: Padding(padding: EdgeInsets.all(22), child: Column(children: [
      Text('تلاوة | TILAWA', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: navy)),
      SizedBox(height: 8), Text('مصمم التطبيق'), Text('محمود أحمد', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: navy)),
      SizedBox(height: 8), Text('الإصدار التجريبي 0.1'),
    ]))),
  ]);
}
